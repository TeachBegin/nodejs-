const path = require('path')

module.exports = {
  name: 'Base Scaffold',

  port: 8080,

  rootPath: path.resolve(__dirname, '../')
}
